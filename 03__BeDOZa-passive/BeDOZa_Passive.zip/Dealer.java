import java.util.Random;

public class Dealer {

    private static Random rand = new Random();

     /* Sampling randomness for Alice and Bob */
    public static int[][][] init() {
        int[][] rsampling_a = new int[5][3];
        int[][] rsampling_b = new int[5][3];

        for (int i = 0; i < 5; i++) {
            int u = rand.nextInt(2);
            int uA = rand.nextInt(2);
            int uB = u ^ uA;

            int v = rand.nextInt(2);
            int vA = rand.nextInt(2);
            int vB = v ^ vA;

            int w = u & v;
            int wA = rand.nextInt(2);
            int wB = w ^ wA;

            rsampling_a[i][0] = uA;
            rsampling_b[i][0] = uB;
            rsampling_a[i][1] = vA;
            rsampling_b[i][1] = vB;
            rsampling_a[i][2] = wA;
            rsampling_b[i][2] = wB;
        }

        return new int[][][] {rsampling_a, rsampling_b};
    }

    /**
     * Convert int (0-7) to 3 bits
     * 3 bit representation based on blood type compatibility matrix
     */
    public static int[] getBits(int val) {
        int[] bits = new int[3];
        bits[0] = (val >> 2) & 1;
        bits[1] = (val >> 1) & 1;
        bits[2] = val & 1;
        return bits;
    }

    /**
     * XOR a single bit with 1
     * 	eqv. notation for \XORC within .tex writeup.
     */
    public static int xorWith1(int val) {
        return val ^ 1;
    }

    /**
     * Calculate d and e shares
     */
    public static int[] calcDEShares(int x, int y, int u, int v) {
        int dShare = x ^ u;
        int eShare = y ^ v;
        return new int[] {dShare, eShare};
    }

    /**
     * Get a single bit (boolean) of a byte at index idx
     */
    public static boolean getBit(int byteVal, int idx) {
        return (byteVal & (1 << idx)) != 0;
    }

    /**
     * Get a single bit as int (0 or 1)
     */
    public static int getBitInt(int byteVal, int idx) {
        return ((byteVal & (1 << idx)) != 0) ? 1 : 0;
    }

    /**
     * Check blood type compatibility: 
     * Where y represents the recipient and  x represents the donor.
     */
    public static int bloodTypeBoolean(int x, int y) {
        int A_bit = 1 ^ ((getBitInt(x, 2) & (1 ^ getBitInt(y, 2))));
        int B_bit = 1 ^ ((getBitInt(x, 1) & (1 ^ getBitInt(y, 1))));
        int R_bit = 1 ^ ((getBitInt(x, 0) & (1 ^ getBitInt(y, 0))));

        return (A_bit & B_bit) & R_bit;
    }
}

