#!/bin/bash


javac *.java

echo
echo "------------------------------------------------"
java ProtocolTest
