import java.util.Random;

public class Alice {

    private static int[] x;
    private static int[] x_a;
    private static int[] x_b;
    private static int[][] u_v_w;
    private static int u, v, w;
    private static int[] y_share;
    private static int[] d_shares;
    private static int[] e_shares;
    private static int[] w_2;
    private static int[] z_share;
    private static int z_share_4;
    private static int z_final;

    private static Random rand = new Random();

    public static void init(int x_in, int[][] u_v_w_in) {
        u_v_w = u_v_w_in;
        x = Dealer.getBits(x_in);
        x_b = new int[] {rand.nextInt(2), rand.nextInt(2), rand.nextInt(2)};
        x_a = createX_a();
        d_shares = new int[3];
        e_shares = new int[3];
    }

    private static int[] createX_a() {
        int[] tmp = new int[x_b.length];
        for (int i = 0; i < x_b.length; i++) {
            tmp[i] = x[i] ^ x_b[i];
        }
        return tmp;
    }

    public static void setYShare(int[] y_in) {
        y_share = y_in;
    }

    public static int[] getYShare() {
        return y_share;
    }

    public static int[] sendXShareToBob() {
        return x_b;
    }

    public static void layer1() {
        int[] new_y = new int[3];
        for (int i = 0; i < 3; i++) {
            new_y[i] = Dealer.xorWith1(y_share[i]);
        }
        setYShare(new_y);
    }

    public static void setUVW(int i) {
        u = u_v_w[i][0];
        v = u_v_w[i][1];
        w = u_v_w[i][2];
    }

    public static void layer2_0() {
        w_2 = new int[3];

        for (int i = 0; i < 3; i++) {
            setUVW(i);
            w_2[i] = w;
            int[] de = Dealer.calcDEShares(x_a[i], y_share[i], u, v);
            d_shares[i] = de[0];
            e_shares[i] = de[1];
        }
    }

    public static int[][] getEDShares() {
        return new int[][] {d_shares, e_shares};
    }

    public static void layer2_1() {
        int[] z = new int[3];
        int[][] bobShares = Bob.getEDShares();
        int[] d_b_shares = bobShares[0];
        int[] e_b_shares = bobShares[1];

        for (int i = 0; i < 3; i++) {
            int e = e_shares[i] ^ e_b_shares[i];
            int d = d_shares[i] ^ d_b_shares[i];
            z[i] = w_2[i] ^ (e & x_a[i]) ^ (d & y_share[i]) ^ (e & d);
        }
        z_share = z;
    }

    public static void layer3() {
        int[] new_z = new int[3];
        for (int i = 0; i < 3; i++) {
            new_z[i] = Dealer.xorWith1(z_share[i]);
        }
        z_share = new_z;
    }

    public static void layer4_0() {
        setUVW(3);
        int[] de = Dealer.calcDEShares(z_share[1], z_share[2], u, v);
        d_shares[0] = de[0];
        e_shares[0] = de[1];
    }

    public static void layer4_1() {
        int[][] bobShares = Bob.getEDShares();
        int[] d_b_shares = bobShares[0];
        int[] e_b_shares = bobShares[1];

        int e = e_shares[0] ^ e_b_shares[0];
        int d = d_shares[0] ^ d_b_shares[0];

        int z = w ^ (e & z_share[1]) ^ (d & z_share[2]);
        z_share_4 = z;
    }

    public static void layer5_0() {
        setUVW(4);
        int[] de = Dealer.calcDEShares(z_share[0], z_share_4, u, v);
        d_shares[0] = de[0];
        e_shares[0] = de[1];
    }

    public static void layer5_1() {
        int[][] bobShares = Bob.getEDShares();
        int[] d_b_shares = bobShares[0];
        int[] e_b_shares = bobShares[1];

        int e = e_shares[0] ^ e_b_shares[0];
        int d = d_shares[0] ^ d_b_shares[0];

        z_final = w ^ (e & z_share[0]) ^ (d & z_share_4) ^ (e & d);
    }

    public static int outputZ() {
        return z_final ^ Bob.getFinalZ();
    }
}

