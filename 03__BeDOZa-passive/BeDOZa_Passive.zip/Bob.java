import java.util.Random;

public class Bob {

    private static int[] y;
    private static int[] y_a;
    private static int[] y_b;
    private static int[][] u_v_w;
    private static int u, v, w;
    private static int[] x_share;
    private static int[] d_shares;
    private static int[] e_shares;
    private static int[] w_2;
    private static int[] z_share;
    private static int z_share_4;
    private static int z_final;

    private static Random rand = new Random();

    public static void init(int y_in, int[][] u_v_w_in) {
        u_v_w = u_v_w_in;
        y = Dealer.getBits(y_in);
        y_a = new int[] {rand.nextInt(2), rand.nextInt(2), rand.nextInt(2)};
        y_b = createY_b();
        d_shares = new int[3];
        e_shares = new int[3];
    }

    private static int[] createY_b() {
        int[] tmp = new int[y_a.length];
        for (int i = 0; i < y_a.length; i++) {
            tmp[i] = y[i] ^ y_a[i];
        }
        return tmp;
    }

    public static void setXShare(int[] x_in) {
        x_share = x_in;
    }

    public static int[] getXShare() {
        return x_share;
    }

    public static int[] sendYShareToAlice() {
        return y_a;
    }

    public static void layer1() {
        // No-op for Bob
    }

    public static void setUVW(int i) {
        u = u_v_w[i][0];
        v = u_v_w[i][1];
        w = u_v_w[i][2];
    }

    public static void layer2_0() {
        w_2 = new int[3];

        for (int i = 0; i < 3; i++) {
            setUVW(i);
            w_2[i] = w;
            int[] de = Dealer.calcDEShares(x_share[i], y_b[i], u, v);
            d_shares[i] = de[0];
            e_shares[i] = de[1];
        }
    }

    public static int[][] getEDShares() {
        return new int[][] {d_shares, e_shares};
    }

    public static void layer2_1() {
        int[] z = new int[3];
        int[][] aliceShares = Alice.getEDShares();
        int[] d_a_shares = aliceShares[0];
        int[] e_a_shares = aliceShares[1];

        for (int i = 0; i < 3; i++) {
            int e = e_shares[i] ^ e_a_shares[i];
            int d = d_shares[i] ^ d_a_shares[i];
            z[i] = w_2[i] ^ (e & x_share[i]) ^ (d & y_b[i]);
        }
        z_share = z;
    }

    public static void layer3() {
        // No-op for Bob
    }

    public static void layer4_0() {
        setUVW(3);
        int[] de = Dealer.calcDEShares(z_share[1], z_share[2], u, v);
        d_shares[0] = de[0];
        e_shares[0] = de[1];
    }

    public static void layer4_1() {
        int[][] aliceShares = Alice.getEDShares();
        int[] d_a_shares = aliceShares[0];
        int[] e_a_shares = aliceShares[1];

        int e = e_shares[0] ^ e_a_shares[0];
        int d = d_shares[0] ^ d_a_shares[0];

        z_share_4 = w ^ (e & z_share[1]) ^ (d & z_share[2]);
    }

    public static void layer5_0() {
        setUVW(4);
        int[] de = Dealer.calcDEShares(z_share[0], z_share_4, u, v);
        d_shares[0] = de[0];
        e_shares[0] = de[1];
    }

    public static void layer5_1() {
        int[][] aliceShares = Alice.getEDShares();
        int[] d_a_shares = aliceShares[0];
        int[] e_a_shares = aliceShares[1];

        int e = e_shares[0] ^ e_a_shares[0];
        int d = d_shares[0] ^ d_a_shares[0];

        z_final = w ^ (e & z_share[0]) ^ (d & z_share_4);
    }

    public static int getFinalZ() {
        return z_final;
    }
}

