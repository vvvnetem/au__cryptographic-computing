/* ProtocolTest */
public class ProtocolTest {

    // Initialize Alice, Bob, and Dealer
    private void initGame(int x, int y) {
        int[][][] rsampling = Dealer.init();
        int[][] rsamplingA = rsampling[0];
        int[][] rsamplingB = rsampling[1];

        Alice.init(x, rsamplingA);
        Bob.init(y, rsamplingB);

        Alice.setYShare(Bob.sendYShareToAlice());
        Bob.setXShare(Alice.sendXShareToBob());
    }
    
    
    private int evalCircuit(int x, int y) {
        initGame(x, y);
		
		// We can build up our circuit as a semantical tree 
		// based on the boolean formula. 
		
        // Layer 1
        Alice.layer1();
        Bob.layer1();

        // Layer 2
        Alice.layer2_0();
        Bob.layer2_0();
        Alice.layer2_1();
        Bob.layer2_1();

        // Layer 3
        Alice.layer3();
        Bob.layer3();

        // Layer 4
        Alice.layer4_0();
        Bob.layer4_0();
        Alice.layer4_1();
        Bob.layer4_1();

        // Layer 5
        Alice.layer5_0();
        Bob.layer5_0();
        Alice.layer5_1();
        Bob.layer5_1();

        return Alice.outputZ();
    }

    // Print a number in 3-bit binary as a string
    private String to3BitString(int val) {
        int[] bits = Dealer.getBits(val);
        return "" + bits[0] + bits[1] + bits[2];
    }

    // Check one test case with 3-bit printout
    private void testScenario(int x, int y) {
        int expected = Dealer.bloodTypeBoolean(x, y);
        int actual = evalCircuit(x, y);
        String donorBits = to3BitString(x);
        String recipientBits = to3BitString(y);

        if (expected != actual) {
            System.out.println("FAIL: donor=" + donorBits + " (" + x + "), recipient=" + recipientBits + " (" + y + ")"
                    + " -> expected=" + expected + ", got=" + actual);
        } else {
            System.out.println(" PASS: donor=" + donorBits + " (" + x + "), recipient=" + recipientBits + " (" + y + ")"
                    + " -> result=" + actual);
        }
    }

    // Run all tests
    public void testParty() {
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                testScenario(i, j);
            }
        }
    }

  

    public static void main(String[] args) {
        ProtocolTest t = new ProtocolTest();
        System.out.println("=== Running: tests for parties ===");
        t.testParty();
    }
}

